class Book:
    """Represents a single book item."""

    def __init__(self, id=None, name="", author="", genre="", status="tbr", rating=""):
        self.id = id
        self.name = name
        self.author = author
        self.genre = genre
        self.status = status
        self.rating = rating

    @classmethod
    def from_tuple(cls, book_tuple):
        """Creates a Book instance directly from a database row tuple."""
        if not book_tuple:
            return None
        return cls(
            id=book_tuple[0],
            name=book_tuple[1],
            author=book_tuple[2],
            genre=book_tuple[3],
            status=book_tuple[4] if len(book_tuple) > 4 else "tbr",
            rating=book_tuple[5] if len(book_tuple) > 5 else ""
        )

    def to_dict(self):
        """Returns book attributes formatted as a dictionary."""
        return {
            "id": self.id,
            "name": self.name,
            "author": self.author,
            "genre": self.genre,
            "status": self.status,
            "rating": self.rating
        }

    def __repr__(self):
        return f"Book(id={self.id}, name='{self.name}', author='{self.author}', genre='{self.genre}', status='{self.status}', rating='{self.rating}')"