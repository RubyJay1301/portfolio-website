import tkinter as tk
from tkinter import messagebox
from tkinter import simpledialog

import database as db

from book import Book

class BookTracker:

    def __init__(self, window):
        
        
        self.window = window

        self.window.title("2026 Book Tracker")
        self.window.geometry("1000x750")

        #Create the database
        db.create_table()

        # - - - - - - - - - - - - - - - - - - - 
        # TITLE
        # - - - - - - - - - - - - - - - - - - -

        title = tk.Label(
            window,
            text="2026 Book tracker",
            font=("Arial", 28)
        )
        title.pack(pady=10)

        # - - - - - - - - - - - - - - - - - - -
        # ADD BOOK SECTION
        # - - - - - - - - - - - - - - - - - - -

        self.create_add_book_section()

        # - - - - - - - - - - - - - - - - - - - - - -
        # SCROLLABLE CONTAINER FOR BOOK SECTIONS
        # - - - - - - - - - - - - - - - - - - - - - -

        container = tk.Frame(window)
        container.pack(fill="both", expand=True, padx=20, pady=10)

        self.canvas = tk.Canvas(container, highlightthickness=0)
        self.scrollbar = tk.Scrollbar(container, orient="vertical", command=self.canvas.yview)

        self.book_sections_frame = tk.Frame(self.canvas)

        self.book_sections_frame.bind(
            "<Configure>",
            lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all"))
        )

        self.canvas_window = self.canvas.create_window((0, 0), window=self.book_sections_frame, anchor="nw")

        self.canvas.bind(
            "<Configure>",
            lambda e: self.canvas.itemconfig(self.canvas_window, width=e.width)
        )

        self.canvas.configure(yscrollcommand=self.scrollbar.set)

        self.scrollbar.pack(side="right", fill="y")
        self.canvas.pack(side="left", fill="both", expand=True)

        self.canvas.bind_all("<MouseWheel>", lambda e:self.canvas.yview_scroll(int(-1 * (e.delta / 120)), "units"))
    
        self.create_sections()
        self.refresh_books()

    # - - - - - - - - - - - - - - - - - - - - - 
    # CREATE THE TWO SECTIONS
    # - - - - - - - - - - - - - - - - - - - - -

    def create_sections(self):

        # TBR
        self.tbr_frame = self.create_status_section(
            "TBR",
            0
        )

        # READ
        self.read_frame = self.create_status_section(
            "READ",
            1
        )

    def create_status_section(self, title, column):

        # Outer section
        section = tk.LabelFrame(
            self.book_sections_frame,
            text=title,
            font=("Arial",16),
            padx=10,
            pady=10
        )

        section.grid(
            row=0,
            column=column,
            padx=10,
            sticky="nsew"
        )

        # Make all three sections equal width
        self.book_sections_frame.columnconfigure(
            column,
            weight=1
        )

        self.book_sections_frame.rowconfigure(0, weight=1)

        return section

    # - - - - - - - - - - - - - - - - - -
    # ADD BOOK FORM
    # - - - - - - - - - - - - - - - - - -

    def create_add_book_section(self):
        
        add_frame = tk.LabelFrame(
            self.window,
            text="Add New Book",
            font=("Arial", 16),
            padx=15,
            pady=15
        )

        add_frame.pack(
            fill="x",
            padx=30,
            pady=10
        )

        # - - - - - - - - - - - - - - - - - -
        # BOOK NAME
        # - - - - - - - - - - - - - - - - - -

        name_label = tk.Label(
            add_frame,
            text="Name:"
        )

        name_label.grid(
            row=0,
            column=0,
            sticky="w",
            padx=5,
            pady=5
        )

        self.name_entry = tk.Entry(
            add_frame,
            width=50
        )

        self.name_entry.grid(
            row=0,
            column=1,
            padx=5,
            pady=5
        )

        # - - - - - - - - - - - - - - - - - - - 
        # AUTHOR
        # - - - - - - - - - - - - - - - - - - -
        author_label = tk.Label(add_frame, text="Author Name:")
        author_label.grid(
            row=1,
            column=0,
            sticky="w",
            padx=5,
            pady=5
        )
        self.author_entry = tk.Entry(add_frame, width=50)
        self.author_entry.grid(
            row=1,
            column=1,
            padx=5,
            pady=5
        )

        # - - - - - - - - - - - - - - - - - - - 
        # GENRE
        # - - - - - - - - - - - - - - - - - - -
        genre_label = tk.Label(add_frame, text="Genre:")
        genre_label.grid(
            row=2,
            column=0,
            sticky="w",
            padx=5,
            pady=5
        )
        self.genre_entry = tk.Entry(add_frame, width=50)
        self.genre_entry.grid(
            row=2,
            column=1,
            padx=5,
            pady=5
        )

        # - - - - - - - - - - - - - - - - - - -
        # ADD BOOK BUTTON
        # - - - - - - - - - - - - - - - - - - -

        add_button = tk.Button(
            add_frame,
            text="Add Book",
            command=self.add_book
        )

        add_button.grid(
            row=3,
            column=1,
            pady=10
        )

    # - - - - - - - - - - - - - - - - 
    # ADD BOOK
    # - - - - - - - - - - - - - - - -

    def add_book(self):
        name = self.name_entry.get().strip()

        author = self.author_entry.get().strip()

        genre = self.genre_entry.get().strip()

        # Check that a name was entered
        if not name:
            messagebox.showerror("Error", "Please enter a book name.")
            return

        db.add_book(name, author, genre)

        self.name_entry.delete(0, tk.END)
        self.author_entry.delete(0, tk.END)
        self.genre_entry.delete(0, tk.END)

        self.refresh_books()

    # - - - - - - - - - - - - - - - - - - - - - - -
    # DISPLAY BOOKS
    # - - - - - - - - - - - - - - - - - - - - - - -

    def refresh_books(self):
        for frame in (self.tbr_frame, self.read_frame):
            for widget in frame.winfo_children():
                widget.destroy()

        # Get books from database
        tbr_books = [Book.from_tuple(t) for t in db.get_books_by_status("tbr")]
        read_books = [Book.from_tuple(t) for t in db.get_books_by_status("read")]

        # Display books
        for book in tbr_books:

            self.display_book(
                self.tbr_frame,
                book
            )

        for book in read_books:

            self.display_book(
                self.read_frame,
                book,
            )

    # - - - - - - - - - - - - - - - -
    # DISPLAY ONE BOOK
    # - - - - - - - - - - - - - - - - 

    def display_book(self, parent_frame, book):
        card = tk.Frame(
            parent_frame,
            relief="groove",
            borderwidth=1,
            padx=8,
            pady=8
        )
        card.pack(fill="x", pady=5)

        tk.Label(card, text=book.name, font=("Arial", 12, "bold")).pack(anchor="w")
        tk.Label(card, text=f"Author: {book.author}").pack(anchor="w")
        tk.Label(card, text=f"Genre: {book.genre}").pack(anchor="w")

        if book.status == "tbr":
            move_button = tk.Button(
                card,
                text="Move to Read",
                command=lambda: self.move_to_read(book.id)
            )
            move_button.pack(pady=5)

        elif book.status == "read":
            rating_str = f"Rating: {book.rating}/5" if book.rating else "Rating: Not rated"
            tk.Label(card, text=rating_str, font=("Arial", 10, "italic")).pack(anchor="w")

            rate_button = tk.Button(
                card,
                text="Edit Rating",
                command=lambda: self.rate_book(book.id)
            )
            rate_button.pack(pady=2)
    # - - - - - - - - - - - - - - - -
    # MOVE BOOK
    # - - - - - - - - - - - - - - - -

    def move_to_read(self, book_id):
        db.move_book(book_id, "read")
        self.rate_book(book_id)

    def rate_book(self, book_id):
        rating = simpledialog.askstring("Book Rating", "Enter rating from 1-5 stars):")
        if rating is not None:
            db.change_book_rating(book_id, rating.strip())
        self.refresh_books()

# - - - - - - - - - - - - - - - -
# START APPLICATION
# - - - - - - - - - - - - - - - -
if __name__ == "__main__": 
    window = tk.Tk()
    app = BookTracker(window)
    window.mainloop()
        