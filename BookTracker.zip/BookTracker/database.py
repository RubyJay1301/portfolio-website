import sqlite3

DATABASE_NAME = "books.db"

def connect_db():
    return sqlite3.connect(DATABASE_NAME)

def create_table():
    connection = connect_db()
    cursor = connection.cursor()

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS books (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            author TEXT,
            genre TEXT,
            status TEXT NOT NULL DEFAULT 'tbr',
            rating TEXT
        )
    """)

    connection.commit()
    connection.close()

def add_book(name, author, genre):
    connection = connect_db()
    cursor = connection.cursor()

    cursor.execute("""
        INSERT INTO books (
            name,
            author,
            genre,
            status,
            rating
        )
        VALUES (?, ?, ?, 'tbr', '')
    """, (name, author, genre))

    connection.commit()
    connection.close()

def get_books_by_status(status):
    connection = connect_db()
    cursor = connection.cursor()

    if status == "read":
        cursor.execute("""
            SELECT id, name, author, genre, status, rating
            FROM books
            WHERE status = ?
            ORDER BY CAST(rating AS INTEGER) DESC
        """, (status,))
    else:
        cursor.execute("""
            SELECT id, name, author, genre, status, rating
            FROM books
            WHERE status = ?
            ORDER BY author
        """, (status,))

    books = cursor.fetchall()
    connection.close()
    return books

def move_book(book_id, new_status):
    connection = connect_db()
    cursor = connection.cursor()

    cursor.execute("""
        UPDATE books
        SET status = ?
        WHERE id = ?
    """, (new_status, book_id))

    connection.commit()
    connection.close()

def get_book(book_id):
    connection = connect_db()
    cursor = connection.cursor()

    cursor.execute("""
        SELECT *
        FROM books
        WHERE id = ?
    """, (book_id,))

    book = cursor.fetchone()
    connection.close()

    return book

def change_book_rating(book_id, book_rating):
    connection = connect_db()
    cursor = connection.cursor()

    cursor.execute("""
        UPDATE books
        SET rating = ?
        WHERE id = ?
    """, (book_rating, book_id))

    connection.commit()
    connection.close()