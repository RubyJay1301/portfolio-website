import tkinter as tk
from tkinter import messagebox

import database as db

from task import Task

class TodoApp:

    def __init__(self, window):

        self.window = window

        self.window.title("To Do List Application")
        self.window.geometry("1000x750")

        #Create the database
        db.create_table()

        # - - - - - - - - - - - - - - - - - - - 
        # TITLE
        # - - - - - - - - - - - - - - - - - - -

        title = tk.Label(
            window,
            text="To Do List Application",
            font=("Arial", 28)
        )
        title.pack(pady=10)

        # - - - - - - - - - - - - - - - - - - -
        # ADD TASK SECTION
        # - - - - - - - - - - - - - - - - - - -

        self.create_add_task_section()

        self.task_sections_frame = tk.Frame(window)
        self.task_sections_frame.pack(
            fill="both",
            expand=True,
            padx=20,
            pady=10
        )

        self.create_sections()
        self.refresh_tasks()

    # - - - - - - - - - - - - - - - - - - - - - 
    # CREATE THE THREE SECTIONS
    # - - - - - - - - - - - - - - - - - - - - -

    def create_sections(self):

        # NOT STARTED
        self.not_started_frame = self.create_status_section(
            "Not Started",
            0
        )

        # IN PROGRESS
        self.in_progress_frame = self.create_status_section(
            "In Progress",
            1
        )

        # COMPLETED
        self.completed_frame = self.create_status_section(
            "Completed",
            2
        )

    def create_status_section(self, title, column):

        # Outer section
        section = tk.LabelFrame(
            self.task_sections_frame,
            text=title,
            font=("Arial",16),
            padx=10,
            pady=10
        )

        section.grid(
            row=0,
            column=column,
            padx=10,
            sticky="nsew"
        )

        # Make all three sections equal width
        self.task_sections_frame.columnconfigure(
            column,
            weight=1
        )

        self.task_sections_frame.rowconfigure(0, weight=1)

        return section

    # - - - - - - - - - - - - - - - - - -
    # ADD TASK FORM
    # - - - - - - - - - - - - - - - - - -

    def create_add_task_section(self):
        
        add_frame = tk.LabelFrame(
            self.window,
            text="Add New Task",
            font=("Arial", 16),
            padx=15,
            pady=15
        )

        add_frame.pack(
            fill="x",
            padx=30,
            pady=10
        )

        # - - - - - - - - - - - - - - - - - -
        # TASK NAME
        # - - - - - - - - - - - - - - - - - -

        name_label = tk.Label(
            add_frame,
            text="Name:"
        )

        name_label.grid(
            row=0,
            column=0,
            sticky="w",
            padx=5,
            pady=5
        )

        self.name_entry = tk.Entry(
            add_frame,
            width=50
        )

        self.name_entry.grid(
            row=0,
            column=1,
            padx=5,
            pady=5
        )

        # - - - - - - - - - - - - - - - - - - - 
        # DUE DATE
        # - - - - - - - - - - - - - - - - - - -
        due_date_label = tk.Label(add_frame, text="Due Date:")
        due_date_label.grid(
            row=1,
            column=0,
            sticky="w",
            padx=5,
            pady=5
        )
        self.due_date_entry = tk.Entry(add_frame, width=50)
        self.due_date_entry.grid(
            row=1,
            column=1,
            padx=5,
            pady=5
        )

        # - - - - - - - - - - - - - - - - - - -
        # EXTRA DETAILS
        # - - - - - - - - - - - - - - - - - - -

        details_label = tk.Label(
            add_frame,
            text="Extra Details:"
        )
        
        details_label.grid(
            row=2,
            column=0,
            sticky="nw",
            padx=5,
            pady=5
        )

        self.details_entry = tk.Text(
            add_frame,
            width=50,
            height=3
        )

        self.details_entry.grid(
            row=2,
            column=1,
            padx=5,
            pady=5
        )

        # - - - - - - - - - - - - - - - - - - -
        # ADD TASK BUTTON
        # - - - - - - - - - - - - - - - - - - -

        add_button = tk.Button(
            add_frame,
            text="Add Task",
            command=self.add_task
        )

        add_button.grid(
            row=3,
            column=1,
            pady=10
        )

    # - - - - - - - - - - - - - - - - 
    # ADD TASK
    # - - - - - - - - - - - - - - - -

    def add_task(self):
        name = self.name_entry.get().strip()

        due_date = self.due_date_entry.get().strip()

        details = self.details_entry.get("1.0", tk.END).strip()

        # Check that a name was entered
        if not name:
            messagebox.showerror("Error", "Please enter a task name.")
            return

        db.add_task(name, due_date, details)

        self.name_entry.delete(0, tk.END)
        self.due_date_entry.delete(0, tk.END)
        self.details_entry.delete("1.0", tk.END)

        self.refresh_tasks()

    # - - - - - - - - - - - - - - - - - - - - - - -
    # DISPLAY TASKS
    # - - - - - - - - - - - - - - - - - - - - - - -

    def refresh_tasks(self):
        for frame in (self.not_started_frame, self.in_progress_frame, self.completed_frame):
            for widget in frame.winfo_children():
                widget.destroy()

        # Get tasks from database
        not_started_tasks = [Task.from_tuple(t) for t in db.get_tasks_by_status("not_started")]
        in_progress_tasks = [Task.from_tuple(t) for t in db.get_tasks_by_status("in_progress")]
        completed_tasks = [Task.from_tuple(t) for t in db.get_tasks_by_status("completed")]

        # Display tasks
        for task in not_started_tasks:

            self.display_task(
                self.not_started_frame,
                task,
                "in_progress"
            )

        for task in in_progress_tasks:

            self.display_task(
                self.in_progress_frame,
                task,
                "completed"
            )

        for task in completed_tasks:

            self.display_task(
                self.completed_frame,
                task,
                None
            )

    # - - - - - - - - - - - - - - - -
    # DISPLAY ONE TASK
    # - - - - - - - - - - - - - - - - 

    def display_task(self, parent_frame, task, next_status):
        task_frame = tk.Frame(
            parent_frame,
            relief="groove",
            borderwidth=1,
            padx=8,
            pady=8
        )
        task_frame.pack(fill="x", pady=5)

        name_label = tk.Label(
            task_frame,
            text=task.name,
            font=("Arial", 12, "bold"),
            cursor="hand2"
        )
        name_label.pack(anchor="w")

        due_label = tk.Label(task_frame, text=f"Due: {task.due_date}")
        due_label.pack(anchor="w")

        name_label.bind(
            "<Button-1>",
            lambda event: self.show_details(task.name, task.due_date, task.details)
        )

        if next_status == "in_progress":
            move_button = tk.Button(
                task_frame,
                text="Move to In Progress",
                command=lambda: self.move_task(task.id, "in_progress")
            )
            move_button.pack(pady=5)

        elif next_status == "completed":
            move_button = tk.Button(
                task_frame,
                text="Move to Completed",
                command=lambda:self.move_task(task.id, "completed")
            )
            move_button.pack(pady=5)

        else:
            delete_button = tk.Button(
                task_frame,
                text="Delete",
                command=lambda tid=task.id: self.delete_task(task.id)
            )
            delete_button.pack(pady=5)

    # - - - - - - - - - - - - - - - -
    # MOVE TASK
    # - - - - - - - - - - - - - - - -

    def move_task(self, task_id, new_status):
        db.move_task(task_id, new_status)
        self.refresh_tasks()

    # - - - - - - - - - - - - - - - -
    # DELETE TASK
    # - - - - - - - - - - - - - - - -

    def delete_task(self, task_id):
        answer = messagebox.askyesno(
            "Delete Task",
            "Are you sure you want to delete this task?"
        )

        if answer:
            db.delete_task(task_id)
            self.refresh_tasks()

    # - - - - - - - - - - - - - - - -
    # SHOW DETAILS
    # - - - - - - - - - - - - - - - -

    def show_details(self, task_name, due_date, details):
        messagebox.showinfo(
            task_name,
            f"Due Date: {due_date}\n\n"
            f"Details:\n{details}"
        )

# - - - - - - - - - - - - - - - -
# START APPLICATION
# - - - - - - - - - - - - - - - -
if __name__ == "__main__": 
    window = tk.Tk()
    app = TodoApp(window)
    window.mainloop()
        