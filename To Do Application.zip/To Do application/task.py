class Task:
    """Represents a single task item."""

    def __init__(self, id=None, name="", due_date="", details="", status="not_started"):
        self.id = id
        self.name = name
        self.due_date = due_date
        self.details = details
        self.status = status

    @classmethod
    def from_tuple(cls, task_tuple):
        """Creates a Task instance directly from a database row tuple."""
        if not task_tuple:
            return None
        return cls(
            id=task_tuple[0],
            name=task_tuple[1],
            due_date=task_tuple[2],
            details=task_tuple[3],
            status=task_tuple[4] if len(task_tuple) > 4 else "not_started"
        )

    def to_dict(self):
        """Returns task attributes formatted as a dictionary."""
        return {
            "id": self.id,
            "name": self.name,
            "due_date": self.due_date,
            "details": self.details,
            "status": self.status
        }

    def __repr__(self):
        return f"Task(id={self.id}, name='{self.name}', due_date='{self.due_date}', status='{self.status}')"