import sqlite3

DATABASE_NAME = "todo.db"

def connect_db():
    # FIXED: Changed sqlite3.connection to sqlite3.connect
    return sqlite3.connect(DATABASE_NAME)

def create_table():
    connection = connect_db()
    cursor = connection.cursor()

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS tasks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            task_name TEXT NOT NULL,
            due_date TEXT,
            task_details TEXT,
            status TEXT NOT NULL DEFAULT 'not_started'
        )
    """)

    # FIXED: Changed connect.commit() to connection.commit()
    connection.commit()
    connection.close()

def add_task(name, due_date, details):
    connection = connect_db()
    cursor = connection.cursor()

    cursor.execute("""
        INSERT INTO tasks (
            task_name,
            due_date,
            task_details,
            status
        )
        VALUES (?, ?, ?, ?)
    """, (name, due_date, details, "not_started"))

    connection.commit()
    connection.close()

def get_tasks_by_status(status):
    connection = connect_db()
    cursor = connection.cursor()

    cursor.execute("""
        SELECT id, task_name, due_date, task_details, status
        FROM tasks
        WHERE status = ?
        ORDER BY due_date
    """, (status,))

    tasks = cursor.fetchall()
    connection.close()

    return tasks

def move_task(task_id, new_status):
    connection = connect_db()
    cursor = connection.cursor()

    cursor.execute("""
        UPDATE tasks
        SET status = ?
        WHERE id = ?
    """, (new_status, task_id))

    connection.commit()
    connection.close()

def delete_task(task_id):
    # FIXED: Changed connection_db() to connect_db()
    connection = connect_db()
    cursor = connection.cursor()

    cursor.execute("""
        DELETE FROM tasks
        WHERE id = ?
    """, (task_id,))

    connection.commit()
    connection.close()

# FIXED: Removed double underscore and added missing colon
def get_task(task_id):
    connection = connect_db()
    cursor = connection.cursor()

    cursor.execute("""
        SELECT *
        FROM tasks
        WHERE id = ?
    """, (task_id,))

    task = cursor.fetchone()
    connection.close()

    return task

def change_due_date(task_id, due_date):
    # FIXED: Corrected cursor assignment, added commit and close
    connection = connect_db()
    cursor = connection.cursor()

    cursor.execute("""
        UPDATE tasks
        SET due_date = ?
        WHERE id = ?
    """, (due_date, task_id))

    connection.commit()
    connection.close()

def change_task_details(task_id, task_details):
    # FIXED: Added missing database setup, cursor, commit, and close
    connection = connect_db()
    cursor = connection.cursor()

    cursor.execute("""
        UPDATE tasks
        SET task_details = ?
        WHERE id = ?
    """, (task_details, task_id))

    connection.commit()
    connection.close()