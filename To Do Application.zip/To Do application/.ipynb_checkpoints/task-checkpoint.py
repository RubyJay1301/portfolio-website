class Task:
    def __init__(self, id, name, due_date, details, status):
        self.id = id
        self.name = name
        self.due_date = due_date
        self.details = details
        self.status = status

        