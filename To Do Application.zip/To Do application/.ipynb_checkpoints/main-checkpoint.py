import tkinter as tk
from tkinter import messagebox
import sqlite3


# - - - - - - - - - - - - -
# DATABASE
# - - - - - - - - - - - - -

DATABASE_NAME = "todo.db"

def connect_db():
    return sqlite3.connect(DATABASE_NAME)

def create_table():
    connection = connect_db()
    cursor = connection.cursor()

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS tasks (
            id INTEGER PRIMARY KEY AUTOINCREMEMENT,
            task_name TEXT NOT NULL,
            due_date TEXT,
            task_details TEXT,
            status TEXT NOT NULL DEFAULT 'not_started'
        )
    """)

    connection.commit()
    connection.close()

def add_task_to_database(name, due_date, details):
    connections = connect_db()
    cursor = connection.cursor()

    cursor.execute("""
        INSERT INTO tasks (
            task_name, 
            due_date,
            task_details,
            status
        )
        VALUES (?, ?, ?, ?)
    """), (name, due_date, details, "not_started")

def get_tasks_by_status(status):
    connection = connect_db()
    cursor = connection.cursor()

    cursor.execute("""
        SELECT id, task_name, due_date, task_details
        FROM tasks
        WHERE status = ?
        ORDER BY due_date
    """, (status,))

    tasks = cursor.fetchall()

    connection.close()

    return tasks

def update_task_status(task_id, new_status):
    connection = connect_db()
    cursor = connection.cursor()

    cursor.execute("""
        UPDATE tasks
        SET status = ?
        WHERE id = ?
    """, (new_status, task_id))

    connection.commit()
    connection.close()

def delete_task_from_database(task_id):
    connection = connect_db()
    cursor = connection.cursor()

    cursor.execute("""
        DELETE FROM tasks
        WHERE id = ?
    """, (task_id,))

    connection.commit()
    connection.close()

# - - - - - - - - - - - - - - - - - - - 
# GUI
# - - - - - - - - - - - - - - - - - - - 

class TodoApp:

    def __init__(self, window):

        self.window = wondow

        self.window.title("To Do List Application")
        self.window.geometry("1000x750")

        #Create the database
        create_table()

        # - - - - - - - - - - - - - - - - - - - 
        # TITLE
        # - - - - - - - - - - - - - - - - - - -

        title = tk.Label(
            widnow,
            text="To Do List Application",
            font=("Arial", 28)
        )

        # - - - - - - - - - - - - - - - - - - -
        # MAIN CONTENT
        # - - - - - - - - - - - - - - - - - - -

        #This frame holds the three sections
        self.task_sections_frame = tk.Frame = tk.Frame(window)

        self.task_sections_frame = tk.Frame(window)

        self.tak_sections_frame.pack(
            fill="both",
            expand=True,
            padx=20
        )

        # - - - - - - - - - - - - - - - - - - -
        # ADD TASK SECTION
        # - - - - - - - - - - - - - - - - - - -

        self.create_add_task_section()

        # Load tasks from database
        self.refresh_tasks()

    # - - - - - - - - - - - - - - - - - - - - - 
    # CREATE THE THREE SECTIONS
    # - - - - - - - - - - - - - - - - - - - - -

    def create_sections(self):

        # NOT STARTED
        self.not_started_frame = self.create_status_section(
            "Not Started",
            0
        )

        # IN PROGRESS
        self.in_progress_frame = self.create_status_section(
            "In Progress",
            1
        )

        # COMPLETED
        self.completed_frame = self.create_status_section(
            "Completed",
            2
        )

    def create_status_section(self, title, column):

        # Outer section
        section = tk.LabelFrame(
            self.task_sections_frame,
            text=title,
            font=("Arial",16),
            padx=10,
            pady=10
        )

        section.grid(
            row=0,
            column=column,
            padx=10,
            sticky="nsew"
        )

        # Make all three sections equal width
        self.task_sections_frame.columnconfigure(
            column,
            weight=1
        )

        return section

    # - - - - - - - - - - - - - - - - - -
    # ADD TASK FORM
    # - - - - - - - - - - - - - - - - - -

    def create_add_task_section(self):
        
        add_frame = tk.LabelFrame(
            self.window,
            text="Add New Task",
            font=("Arial", 16),
            padx=15,
            pady=15
        )

        add_frame.pack(
            fill="x",
            padx=30,
            pady=20
        )

        # - - - - - - - - - - - - - - - - - -
        # TASK NAME
        # - - - - - - - - - - - - - - - - - -

        name_label = tk.Label(
            add_frame,
            text="Name:"
        )

        name_label.grid(
            row=0,
            column=0,
            sticky="w",
            padx=5,
            pady=5
        )

        self.name_entry = tk.Entry(
            add_frame,
            width=50
        )

        self.name_entry.grid(
            row=0,
            column=1,
            padx=5,
            pady=5
        )

        # - - - - - - - - - - - - - - - - - - - 
        # DUE DATE
        # - - - - - - - - - - - - - - - - - - -

        due_date_label.grid(
            row=1,
            column=0,
            sticky="w",
            padx=5,
            pady=5
        )

        self.due_date_entry.grid(
            row=1,
            column=1,
            padx=5,
            pady=5
        )

        # - - - - - - - - - - - - - - - - - - -
        # EXTRA DETAILS
        # - - - - - - - - - - - - - - - - - - -

        details_label = tk.Label(
            add_frame,
            text="Extra Details:"
        )
        
        details_label.grid(
            row=2,
            column=0,
            sticky="nw,
            padx=5,
            pady=5
        )

        self.details_entry = tk.Text(
            add_frame,
            width=50,
            height=4
        )

        self.details_entry.grid(
            row=2,
            column=1,
            padx=5,
            pady=5
        )

        # - - - - - - - - - - - - - - - - - - -
        # ADD TASK BUTTON
        # - - - - - - - - - - - - - - - - - - -

        add_button = tk.Button(
            add_frame,
            text="Add Task",
            command=self.add_task
        )

        add_button.grid(
            row=3,
            column=1,
            pady=10
        )

    # - - - - - - - - - - - - - - - - 
    # ADD TASK
    # - - - - - - - - - - - - - - - -

    def add_task(self):
        name = self.name_entry.get()

        due_date = self.due_date_entry.get()

        details = self.details_entry.get(
            "1.0",
            tk.END
        ).strip()

        # Check that a name was entered
        if name == "":
            messagebox.showerror(
                "Error",
                "Please enter a task name."
            )

            return

        # Add task to database
        add_task_to_database(
            name,
            due_date,
            details
        )

        # Clear the input fields
        self.name_entry.delete(
            0,
            tk.END
        )

        self.due_date_entry.delete(
            0,
            tk.END
        )

        self.details_entry.delete(
            "1.0",
            tk.END
        )

        # Refresh the GUI
        self.refresh_tasks()

    # - - - - - - - - - - - - - - - - - - - - - - -
    # DISPLAY TASKS
    # - - - - - - - - - - - - - - - - - - - - - - -

    def refresh_tasks(self):

        #Remove all currently displayed tasks
        for widget in self.not_started_frame.winfor_children():
            widget.destroy()

        for widget in self.in_progress_fram.winfor_children():
            widget.destroy()

        for widget in self.completed_frame.winfor_children():
            widget.destroy()

        # Get tasks from database
        not_started_tasks = get_tasks_by_status(
            "not_started"
        )

        in_progress_tasks = get_taks_by_status(
            "in_progress"
        )

        completed_tasks = get_tasks_by_status(
            "completed"
        )

        # Display tasks
        for task in not_started_tasks:

            self.displat_task(
                self.not_started_frame,
                task,
                "in_progress"
            )

        for task in in_progress_tasks:

            self.display_task(
                self.in_progress_frame,
                task,
                "completed"
            )

        for task in completed_tasks:

            self.display_task(
                self.completed_frame,
                task,
                NONE
            )

    # - - - - - - - - - - - - - - - -
    # DISPLAY ONE TASK
    # - - - - - - - - - - - - - - - - 

    def display_task(
        self,
        parent_frame,
        task,
        next_status
    ):

        task_id = task[0]
        task_name = task[1]
        due_date = task[2]
        task_details = task[3]

        # - - - - - - - - - - - - - - - - - -
        # TASK DETAILS
        # - - - - - - - - - - - - - - - - - -

        task_frame = tk.Frame(
            parent_frame,
            relief="groove",
            borderwidth=1,
            padx=8,
            pady=8
        )

        task_frame.pack(
            fill="x",
            pady=5
        )

        # - - - - - - - - - - - - - - - - 
        # TASK NAME
        # - - - - - - - - - - - - - - - - 

        name_label = tk.Label(
            task_frame,
            text=task_name,
            font=("Arial", 12, "bold"),
            cursor="hadn2"
        )

        # - - - - - - - - - - - - - - - - 
        # DUE DATE
        # - - - - - - - - - - - - - - - - 

        due_label = tk.Label(
            task_frame,
            text=f"Due: {due_date}"
        )

        due_label.pack(
            anchor="w"
        )

        # - - - - - - - - - - - - - - - -
        # CLICK TASK TO SHOW DETAILS
        # - - - - - - - - - - - - - - - - 

        name_label.bind(
            "<Button-1>",
            lambda event: self.show_details(
                task_name,
                due_date,
                task_details
            )
        )

        # - - - - - - - - - - - - - - - -
        # BUTTON
        # - - - - - - - - - - - - - - - -

        if next_status == "in_progress":
            move_button = tk.Button(
                task_frame,
                text="Move to In Progress",
                command=lambda: self.move_task(
                    task_id,
                    "in_progress"
                )
            )

            move_button.pack(
                pady=5
            )

        elif next_status == "completed":

            move_button = tk.Button(
                task_frame,
                text="Move to Completed",
                command=lambda: self.move_task(
                    task_id,
                    "completed"
                )
            )

            move_button.pack(
                pady=5
            )

        else:

            delete button = tk.Button(
                task_frame,
                text="Delete",
                command=lambda: self.delete_task(
                    task_id
                )
            )

            delete_button.pack(
                pady=5
            )

    # - - - - - - - - - - - - - - - -
    # MOVE TASK
    # - - - - - - - - - - - - - - - -

    def move_task(self, task_id, new_status):

        update_task_status(
            task_id,
            new_status
        )

        self.refresh_tasks()

    # - - - - - - - - - - - - - - - -
    # DELETE TASK
    # - - - - - - - - - - - - - - - -

    def delete_task(self, task_id):
        answer = messagebox.askyesno(
            "Delete Task",
            "Are you sure you want to delete this task?"
        )

        if answer:

            delete_task_from_database(
                task_id
            )

            self.refresh_tasks()

    # - - - - - - - - - - - - - - - -
    # SHOW DETAILS
    # - - - - - - - - - - - - - - - -

    def show_details(
        self, 
        task_name,
        due_date,
        details
    ):
        messagebox.showinfo(
            task_name,
            f"Due Date: {due_date}\n\n"
            f"Details:\n{details}"
        )

# - - - - - - - - - - - - - - - -
# START APPLICATION
# - - - - - - - - - - - - - - - -

window = tk.Tk()

app = TodoApp(window)

window.mainloop()
        
    







#when user pressed add task
add_task(
    "Task",
    "21-07-2026",
    "Task details"
)
#The new task automatically appears in Not Started

#get tasks by status function
not_started = get_tasks_by_status("not_started")
in_progress = get_tasks_by_status("in_progress")
completed = get_tasks_by_status("completed")

#Moving a task to in progress
move_task(1, "in_progress")

#completing a task
move_task(1, "completed")

#deleting a task
delete_task(1)

#To show all information about a task
get_task(1)

#changing due date
change_due_date(1, "01-02-2026")

#changing task details
change_task_details(1, "new task details")